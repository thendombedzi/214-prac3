#ifndef WOODLAND_I_H
#define WOODLAND_I_H

#include "Infantry.h"


class Woodland_I : public Infantry{
    public:
     void move();
     void attack();
};

#endif