#include <iostream>
#include "LegionUnit.h"

LegionUnit::~LegionUnit()
{}