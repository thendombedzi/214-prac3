#ifndef WOODLAND_C_H
#define WOODLAND_C_H

#include "Cavalry.h"


class Woodland_C : public Cavalry{
    public:
     void move();
     void attack();
};

#endif