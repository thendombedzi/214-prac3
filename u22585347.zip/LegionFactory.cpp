#include <iostream>
#include "LegionFactory.h"

LegionFactory::~LegionFactory()
{}