# 214-prac3
This repository contains the code for Software Modelling (2nd Year) Practical 3. The project integrates four key design patterns: Abstract Factory, Strategy, Memento, and Composite, into a unified and functional codebase.





Class : UnitComponent
 - 