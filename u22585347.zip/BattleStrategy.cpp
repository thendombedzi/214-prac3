#include <iostream>

#include "BattleStrategy.h"

using namespace std;

BattleStrategy::~BattleStrategy() 
{ }