#ifndef OPENFIELD_I_H
#define OPENFIELD_I_H

#include "Infantry.h"


class OpenField_I : public Infantry{
    public:
     void move();
     void attack();
     ~OpenField_I() override;
};

#endif