#ifndef RIVERBANK_I_H
#define RIVERBANK_I_H

#include "Infantry.h"


class Riverbank_I : public Infantry{
    public:
     void move();
     void attack();
};

#endif