#ifndef RIVERBANK_A_H
#define RIVERBANK_A_H

#include "Artillery.h"


class Riverbank_A : public Artillery{
    public:
     void move();
     void attack();
};

#endif