#ifndef WOODLAND_A_H
#define WOODLAND_A_H

#include "Artillery.h"


class Woodland_A : public Artillery{
    public:
     void move();
     void attack();
};

#endif