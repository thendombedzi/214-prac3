#ifndef RIVERBANK_C_H
#define RIVERBANK_C_H

#include "Cavalry.h"


class Riverbank_C : public Cavalry{
    public:
     void move();
     void attack();
};

#endif